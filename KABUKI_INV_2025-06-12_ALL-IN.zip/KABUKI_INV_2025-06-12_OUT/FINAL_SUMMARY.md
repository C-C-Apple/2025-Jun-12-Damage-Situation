# KABUKI-INV 最終レポート要約（2025-06-12 再分析）

## 観測ポイント（抜粋）
- 2025-06-12 11:25:11+0700 | bug_type_event | bug_type=298 | None
- 2025-06-12 12:05:19+0700 | bug_type_event | bug_type=225 | None
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None |  com.cebbank.ebank
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None |  com.hp.printer.control
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None | com.czzhao.binance
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None |  com.apple.reminders
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None |  com.google.Maps
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None |  com.google.ios.youtube
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None | com.apple.journal
- 2025-06-12 12:05:19+0700 | xp_amp_app_usage_dnu | bug_type=None | com.bybit.app

## カテゴリ・ヒット数（Top 6）
- BUG_TYPES: 108
- FLAME: 58
- VENDORS: 46
- LOG/SYSTEM: 29
- APPS/VOIP/FIN/SNS: 15
- EXT/UI JACK: 9

## 連携スコア（概要）
- 同秒クラスタ: 14
- ±60秒クラスタ: 12
- ±5分クラスタ: 12